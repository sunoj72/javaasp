import java.time.Instant;

public class StaticFiledTEst {

	private static int staticInt = 100;
	
	public static void main(String[] args) {
		StaticFiledTEst a = new StaticFiledTEst();
		System.out.println(a.getStaticInt());
		
		StaticFiledTEst b = new StaticFiledTEst();
		System.out.println(b.getStaticInt());
		System.out.println(a.getStaticInt());
		System.out.println(b.getStaticInt());
		
		
		Instant aa = Instant.now().minusSeconds(120);
		System.out.println(aa.toString());

	}
	
	public void addStaticint() {
		staticInt++;
	}

	public int getStaticInt() {
		return staticInt++;
	}
}
