# javaasp

* Reference Site

- File IO
  - 라인단위 파일 읽기 : https://mkyong.com/java8/java-8-stream-read-a-file-line-by-line/

- String.format
  - http://blog.devez.net/100
  - http://micropai.tistory.com/48

- java 8 stream
  - 스트림 기본 : https://yongho1037.tistory.com/702?category=686117
  
  
- Thread
  - http://eaco.tistory.com/3
  - https://wikidocs.net/230
  - http://blog.eomdev.com/java/2016/04/06/Multi-Thread.html

- Collection
  - Map을 정렬하는 다양한 방법 : https://codechacha.com/ko/java-sort-map/
  
  